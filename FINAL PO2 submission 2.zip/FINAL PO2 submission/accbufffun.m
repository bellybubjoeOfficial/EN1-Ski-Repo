function [acc_calib, acc_buff]=accbufffun(acc_buff)
acc_buff.ax(1:end-1)=acc_buff.ax(2:end);
acc_buff.ay(1:end-1)=acc_buff.ay(2:end);
acc_buff.az(1:end-1)=acc_buff.az(2:end);
acc_buff.ax(end)=kk(1);
acc_buff.ay(end)=kk(2);
acc_buff.az(end)=kk(3);

acc_calib.ax=mean(acc_buff.ax);
acc_calib.ay=mean(acc_buff.ay);
acc_calib.az=mean(acc_buff.az);