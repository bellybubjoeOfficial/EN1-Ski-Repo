function myserialfun3D_v2a(src,~)
global tlast imu_raw imu_grav acc_buff ggplot
data = readline(src);
%textmessage=char(data);
GyroGain=1;
if isempty(data)==0
    gg=split(data,'	');
    
    jjj=0;
    for jj=1:length(gg)
        hh=split(gg(jj));
        if isempty(hh)==0
            jjj=jjj+1;
            
            kk(jjj)=str2num(hh(end));
        end
    end
    
    
    tnow=cputime;
    Tdelt=tnow-tlast;
    
    if (Tdelt>=0.01)&& (length(kk)>=6)
        
        delqz= GyroGain*kk(6)*Tdelt;  %Small twist: angular vel z Tdelt
        delqy= GyroGain*kk(5)*Tdelt;  %Small twist: angular vel x Tdelt
        delqx= GyroGain*kk(4)*Tdelt;  %Small twist: angular vel y Tdelt
        
        imu_raw.ax=kk(1);
        imu_raw.ay=kk(2);
        imu_raw.az=kk(3);
        
        imu_raw.wx=kk(4);
        imu_raw.wy=kk(5);
        imu_raw.wz=kk(6);
        
        imu_raw.qx=integ(imu_raw.qx, kk(4), Tdelt);
        imu_raw.qy=integ(imu_raw.qy, kk(5), Tdelt);
        imu_raw.qz=integ(imu_raw.qz, kk(6), Tdelt);
        
        Oxyz=mean(ggplot.Vertices);
        Xpoint=mean(ggplot.Vertices([2 3 6 7],:));
        Ypoint=mean(ggplot.Vertices([3 4 7 8],:));
        Zpoint=mean(ggplot.Vertices(5:8,:));
        Xvect=Xpoint-Oxyz;
        Yvect=Ypoint-Oxyz;
        Zvect=Zpoint-Oxyz;
         
        % rotate(ggplot,Zvect, delqz*180/pi);
        % rotate(ggplot,Yvect, delqy*180/pi);
        % rotate(ggplot,Xvect, delqx*180/pi);
        
        
        %
        acc_buff.ax(1:end-1)=acc_buff.ax(2:end);
        acc_buff.ay(1:end-1)=acc_buff.ay(2:end);
        acc_buff.az(1:end-1)=acc_buff.az(2:end);
        acc_buff.ax(end)=kk(1);
        acc_buff.ay(end)=kk(2);
        acc_buff.az(end)=kk(3);
        
        acc_calib.ax=mean(acc_buff.ax);
        acc_calib.ay=mean(acc_buff.ay);
        acc_calib.az=mean(acc_buff.az);
        %
        
        
        
        
        acc_grav=gravitycalib([acc_calib.ax acc_calib.ay acc_calib.az] , [imu_raw.ax imu_raw.ay imu_raw.az]);
        
                imu_grav.ax=acc_grav(1);
                imu_grav.ay=acc_grav(2);
                imu_grav.az=acc_grav(3);
                

        imu_grav.vx=integ(imu_grav.vx, acc_grav(1), Tdelt);
        imu_grav.vy=integ(imu_grav.vy, acc_grav(2), Tdelt);
        imu_grav.vz=integ(imu_grav.vz, acc_grav(3), Tdelt);
        imu_grav.px=integ(imu_grav.px, imu_grav.vx, Tdelt);
        imu_grav.py=integ(imu_grav.py, imu_grav.vy, Tdelt);
        imu_grav.pz=integ(imu_grav.pz, imu_grav.vz, Tdelt);
        
        
        Xnorm=Xvect/norm(Xvect);
        Ynorm=Yvect/norm(Yvect);
        Znorm=Zvect/norm(Zvect);
        
        imu_raw.qzr=atan2(Xnorm(2), Xnorm(1));
        imu_raw.qyr=atan2(Znorm(2), Znorm(1));
        imu_raw.qxr=atan2(Ynorm(2), Ynorm(1));
        
        %PosDelta=[Xnorm*imu_grav.vx*Tdelt+Ynorm*vy*Tdelt+Znorm*vz*Tdelt];
        %PosDelta=[Xnorm*imu_grav.vx*Tdelt];
        %PosDeltaVertices=repmat(PosDelta,8,1);
        %ggplot.Vertices=ggplot.Vertices+PosDeltaVertices;
        %drawnow
    end
    tlast=tnow;
    
end
%drawnow limitrate

