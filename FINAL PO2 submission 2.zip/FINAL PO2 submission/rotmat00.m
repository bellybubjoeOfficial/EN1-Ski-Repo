function xxyy=rotmat00(theta)

xxyy=[cos(theta) -sin(theta); sin(theta) cos(theta)];