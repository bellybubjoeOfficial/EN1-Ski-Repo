function ysum=integ(ysum, data, tdelt)

ysum=ysum+data*tdelt;