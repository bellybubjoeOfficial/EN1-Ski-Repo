function y=ResetFun(src,event)
global tlast qx qy qz ggplot rotvectx rotvecty rotvectz   vert fac
kk=event.Key;
switch kk
    case 'leftarrow'
        rotvectx=[1 0 0];
        rotvecty=[0 1 0];
        rotvectz=[0 0 1];
        set(ggplot, 'Vertices',vert,'Faces',fac);
    otherwise
end

