%This is the example main loop to read IMU data
%The needed files: MyserialfunRead, SensorObjectStates, accbufffun, integ

clear
close all
sensorvalues=[0 0 0 0 0];
global tlast  imu_raw imu_grav acc_buff ggplot fac vert

tlast=cputime;
imu_grav.vx=0;
imu_grav.vy=0;
imu_grav.vz=0;
imu_grav.px=0;
imu_grav.py=0;
imu_grav.pz=0;

acc_buff.ax=zeros(20,1);
acc_buff.ay=zeros(20,1);
acc_buff.az=zeros(20,1);
imu_raw.qx=0;
imu_raw.qy=0;
imu_raw.qz=0;

imu_raw.ax=0;
imu_raw.ay=0;
imu_raw.az=0;

imu_raw.wx=0;
imu_raw.wy=0;
imu_raw.wz=0;

theta=0;
%Set up serial port
%select COM option for windows
%arduinoObj = serialport("/dev/cu.usbserial-0001",115200,"Timeout",5);
arduinoObj = serialport("/dev/cu.usbserial-0001",115200,"Timeout",5);
pause(5)
configureTerminator(arduinoObj,"CR")
%configureCallback(arduinoObj,"byte",50,@myserialfun3D_v2a)
warning off
%warning on

hfig=figure(100);
set(hfig,'KeyPressFcn',@ResetFun);
set(hfig,'DeleteFcn',@CleanUpFun);

axis equal

xs0=-2; xs1=2;
ys0=-1; ys1=1;
zs0=-0.5; zs1=0.5;
vert = [xs0 ys0 zs0;xs1 ys0 zs0;xs1 ys1 zs0;xs0 ys1 zs0;xs0 ys0 zs1;xs1 ys0 zs1;xs1 ys1 zs1;xs0 ys1 zs1];
fac = [1 2 6 5;2 3 7 6;3 4 8 7;4 1 5 8;1 2 3 4;5 6 7 8];
ggplot=patch('Vertices',vert,'Faces',fac,...
    'FaceVertexCData',hsv(6),'FaceColor','flat');
%ggplot=patch('Vertices',vert,'Faces',fac,...
%    'FaceVertexCData',hsv(6),'FaceColor','flat', 'visible', 'offf');
view(3)
Oxzy=mean(ggplot.Vertices);
Xpoint=mean(ggplot.Vertices([2 3 6 7],:));
Ypoint=mean(ggplot.Vertices([3 4 7 8],:));
Zpoint=mean(ggplot.Vertices(5:8,:));

hold on
axis equal
axis([ -1  1    -1  1    -1  1]*5)
grid on
counter=0;
tlast=cputime;


%This is the main while loop
while(counter<10000)
    counter=counter+1;
    imu_raw=MyserialFunRead(arduinoObj, imu_raw)
    [imu_raw, ggplot, tlast]=SensorObjectStates(ggplot, imu_raw, tlast);
end



function CleanUpFun(src,event)
clear arduinoObj
disp('Cleaning up arduino connection');
end

function ResetFun(src,event)
global tlast  imu_raw imu_grav acc_buff ggplot fac vert
kk=event.Key;
switch kk
    case 'leftarrow'
        set(ggplot, 'Vertices',vert,'Faces',fac);
        disp('Reset IMU Position/Orientation');
        imu_grav.vx=0;
        imu_grav.vy=0;
        imu_grav.vz=0;
        imu_grav.px=0;
        imu_grav.py=0;
        imu_grav.pz=0;
        
    otherwise
end
end