function acc_grav=gravitycalib(acc_calib, raw_accel)
aax=raw_accel(1); 
aay=raw_accel(2); 
aaz=raw_accel(3);
acx=acc_calib(1); 
acy=acc_calib(2); 
acz=acc_calib(3);

accnorm=sqrt(acx^2+acy^2+acz^2);
Ax=(acx)/accnorm;
Ay=(acy)/accnorm;
Az=(acz)/accnorm;
Axy=Ax^2 +Ay^2;
RR(1,1)=(+Ay*Ay-Ax*Ax*Az)/Axy;
RR(1,2)=(-Ax*Ay-Ax*Ay*Az)/Axy;
RR(1,3)=Ax;

RR(2,1)=RR(1,2);
RR(2,2)=(+Ax*Ax-Ay*Ay*Az)/Axy;
RR(2,3)=Ay;

RR(3,1)=-Ax;
RR(3,2)=-Ay;
RR(3,3)=-Az;
acc0=RR*[aax; aay;  aaz];
acc_grav=[acc0(1), acc0(2), acc0(3)+9.81];


