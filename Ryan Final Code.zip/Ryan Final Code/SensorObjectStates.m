function [imu_raw, ggplot, tlast]=SensorObjectStates(ggplot, imu_raw, tlast)
GyroGain=1;
tnow=cputime;
Tdelt=tnow-tlast;

delqz= GyroGain*imu_raw.wz*Tdelt;  %Small twist: angular vel z Tdelt
delqy= GyroGain*imu_raw.wy*Tdelt;  %Small twist: angular vel x Tdelt
delqx= GyroGain*imu_raw.wx*Tdelt;  %Small twist: angular vel y Tdelt

% Oxyz=mean(ggplot.Vertices);
% Xpoint=mean(ggplot.Vertices([2 3 6 7],:));
% Ypoint=mean(ggplot.Vertices([3 4 7 8],:));
% Zpoint=mean(ggplot.Vertices(5:8,:));
% Xvect=Xpoint-Oxyz;
% Yvect=Ypoint-Oxyz;
% Zvect=Zpoint-Oxyz;

% rotate(ggplot,Zvect, delqz*180/pi);
% rotate(ggplot,Yvect, delqy*180/pi);
% rotate(ggplot,Xvect, delqx*180/pi);

imu_raw.qx=integ(imu_raw.qx, imu_raw.wx, Tdelt);
imu_raw.qy=integ(imu_raw.qy, imu_raw.wy, Tdelt);
imu_raw.qz=integ(imu_raw.qz, imu_raw.wz, Tdelt);



tlast=tnow;

