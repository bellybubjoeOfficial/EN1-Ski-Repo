function myserialfun3D(src,~)
global tlast qx qy qz vx vy vz ggplot rotvectx rotvecty rotvectz
data = readline(src);
%textmessage=char(data);

if isempty(data)==0
    gg=split(data,'	');

    jjj=0;
    for jj=1:length(gg)
        hh=split(gg(jj));
        if isempty(hh)==0
            jjj=jjj+1;

            kk(jjj)=str2num(hh(end));
        end
    end

    %assignin('base', 'sensorvalues', kk );
    %assignin('base', 'q', q_last );

    tnow=cputime;
    Tdelt=tnow-tlast;
    if (Tdelt>=0.01)&& (length(kk)>=6)

        %qx=integ(qx, kk(4), Tdelt);
        %qy=integ(qy, kk(5), Tdelt);
        %qz=integ(qz, kk(6), Tdelt);
        qx= 0*kk(5)*Tdelt;

        %RRy=[cos(qy), 0, sin(qy);  0 , 1, 0; -sin(qy), 0, cos(qy) ];

        %RRz=[cos(qz), -sin(qz), 0; sin(qz), cos(qz), 0; 0 , 0, 1 ];
        %RRx=[1, 0, 0; 0, cos(qx), -sin(qx); 0 , sin(qx), cos(qx) ];
        %RRR=RRz*RRy*RRx;
        %rotvectz=(RRR*rotvectz')';

        %rotate(ggplot,[0 0 1],.5*kk(6)*Tdelt*180/pi);
        %qz= .5*kk(6)*Tdelt;
        %RRz=[cos(qz), -sin(qz), 0; sin(qz), cos(qz), 0; 0 , 0, 1 ];
        %rotvecty=(RRz*rotvecty')';
        %rotvectx=(RRz*rotvectx')';
        rotate(ggplot,[0 0 1],1*kk(6)*Tdelt*180/pi);
        rotate(ggplot,[0 1 0],1*kk(5)*Tdelt*180/pi);
        rotate(ggplot,[1 0 0],1*kk(4)*Tdelt*180/pi);

        qy= 0.5*kk(5)*Tdelt;
        

        %rotate(ggplot,[0 0 1],.5*kk(6)*Tdelt*180/pi);
        %rotate(ggplot,[0 1 0],.5*kk(5)*Tdelt*180/pi);
        %rotate(ggplot,[1 0 0],.5*kk(4)*Tdelt*180/pi);

        vx=integ(vx, kk(1), Tdelt);
        vy=integ(vy, kk(2), Tdelt);
        vz=integ(vz, kk(3), Tdelt);


        tlast=tnow;
    end

end
%drawnow limitrate

