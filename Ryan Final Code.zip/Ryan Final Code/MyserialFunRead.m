function imu_raw=MyserialFunRead(arduinoObj, imu_raw)
data = readline(arduinoObj);

if length(split(data))>12
    if isempty(data)==0
        gg=split(data,'	');
        
        jjj=0;
        for jj=1:length(gg)
            hh=split(gg(jj));
            if isempty(hh)==0
                jjj=jjj+1;
                
                kk(jjj)=str2num(hh(end));
            end
        end
    end
    
    
    imu_raw.ax=kk(1); %linear acceleration
    imu_raw.ay=kk(2);
    imu_raw.az=kk(3);
    imu_raw.wx=kk(4); %angular velocity
    imu_raw.wy=kk(5);
    imu_raw.wz=kk(6);
end