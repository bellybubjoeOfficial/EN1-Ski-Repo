function myserialfun3D_v2(src,~)
global tlast qx qy qz qabs_x qabs_y qabs_z wx wy wz vx vy vz ggplot
data = readline(src);
%textmessage=char(data);
GyroGain=1;
if isempty(data)==0
    gg=split(data,'	');
    
    jjj=0;
    for jj=1:length(gg)
        hh=split(gg(jj));
        if isempty(hh)==0
            jjj=jjj+1;
            
            kk(jjj)=str2num(hh(end));
        end
    end
    
    %assignin('base', 'sensorvalues', kk );
    %assignin('base', 'q', q_last );
    
    tnow=cputime;
    Tdelt=tnow-tlast;
    if (Tdelt>=0.01)&& (length(kk)>=6)
        
        qz= GyroGain*kk(6)*Tdelt;  %Small twist: angular vel z Tdelt
        qy= GyroGain*kk(5)*Tdelt;  %Small twist: angular vel x Tdelt
        qx= GyroGain*kk(4)*Tdelt;  %Small twist: angular vel y Tdelt

        %integrated angular positions
                qabs_x=integ(qabs_x, kk(4), Tdelt);
                qabs_y=integ(qabs_y, kk(5), Tdelt);
                qabs_z=integ(qabs_z, kk(6), Tdelt);

        wx=kk(4);
        wy=kk(5);
        wz=kk(6);
        
        
        Oxyz=mean(ggplot.Vertices);
        Xpoint=mean(ggplot.Vertices([2 3 6 7],:));
        Ypoint=mean(ggplot.Vertices([3 4 7 8],:));
        Zpoint=mean(ggplot.Vertices(5:8,:));
        Xvect=Xpoint-Oxyz;
        Yvect=Ypoint-Oxyz;
        Zvect=Zpoint-Oxyz;
        
        rotate(ggplot,Zvect,qz*180/pi);
        rotate(ggplot,Yvect,qy*180/pi);
        rotate(ggplot,Xvect,qx*180/pi);
        
        %vx=integ(vx, kk(1), Tdelt);
        %vy=integ(vy, kk(2), Tdelt);
        %vz=integ(vz, kk(3), Tdelt);
        
        
        %Xnorm=Xvect/norm(Xvect);
        %Ynorm=Yvect/norm(Yvect);
        %Znorm=Zvect/norm(Zvect);
        
        %PosDelta=[Xnorm*vx*Tdelt+Ynorm*vy*Tdelt+Znorm*vz*Tdelt];
        %PosDeltaVertices=repmat(PosDelta,8);
        %ggplot.Vertices=ggplot.Vertices+PosDeltaVertices;'

        %Do not use drawnow on mac
        %drawnow
    end
    tlast=tnow;
    
end
%drawnow limitrate

