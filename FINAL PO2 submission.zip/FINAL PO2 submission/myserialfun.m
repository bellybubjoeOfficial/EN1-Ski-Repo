function myserialfun(src,~)
global tlast theta_last ggplot  xxpoints yypoints
data = readline(src);
%textmessage=char(data);

if isempty(data)==0
gg=split(data,'	');

jjj=0;
for jj=1:length(gg)
    hh=split(gg(jj));
    if isempty(hh)==0
        jjj=jjj+1;
         
        kk(jjj)=str2num(hh(end));
    end
end

%assignin('base', 'sensorvalues', kk );
%assignin('base', 'theta', theta_last );

tnow=cputime;
Tdelt=tnow-tlast;

if (Tdelt>0.01)&& (length(kk)>=6)
    theta_last=integ(theta_last, kk(6), Tdelt);
    xxyy=rotmat00(theta_last)*[xxpoints; yypoints];
    set(ggplot, 'xdata', xxyy(1,:),'ydata', xxyy(2,:) )
    %drawnow
end
end


tlast=tnow;

%drawnow limitrate

