clear
close all
sensorvalues=[0 0 0 0 0];
global theta_last tlast ggplot  xxpoints yypoints
tlast=cputime;
theta_last=0;
theta=0;
%Set up serial port
arduinoObj = serialport("/dev/cu.usbserial-0001",115200,"Timeout",5);
%arduinoObj = serialport("COM3",115200,"Timeout",5);

configureTerminator(arduinoObj,"CR")
configureCallback(arduinoObj,"byte",50,@myserialfun)
warning off
figure(1);
% t = timer;
% t.StartDelay = 0;
% t.ExecutionMode = 'fixedRate';
% t.TimerFcn = @(~,~)drawnow;
% t.Period = .01; %update every 1 sec.
% t.TasksToExecute=1000;

xlim([-500 500])
ylim([-500 500])
axis equal
xxpoints=[-100 100 100 -100 -100]*2;
yypoints=[100 100 -100 -100 100];

ggplot=patch(xxpoints,yypoints, 'c');

%start(t)                        % start drawnow timer
% for jj=1:2000
% end
% 
% stop(t) %stop timer
% clear arduinoObj;

%for jj=1:2000
%AngVelX=sensorvalues(3);
%theta
%xxyy=rotmat00(theta)*[xxpoints; yypoints];
%set(gg, 'xdata', xxyy(1,:),'ydata', xxyy(2,:) )
%drawnow
%end
%tic
%datanow=get_arduino_serial_data(arduinoObj)
%toc
%Clean up serial port
%clear arduinoObj;
