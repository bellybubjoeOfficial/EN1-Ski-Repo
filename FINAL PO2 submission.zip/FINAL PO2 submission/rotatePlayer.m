function rotatePlayer()
global force SystemParams gateSpeed imu_raw imu_original terminalSpeed

%change in force for puhses
DeltaForce=0.00001;
maxForce=1;
minForce=-1;
%change speedScale to change sensitivity to rotation
speedScale = 1;


%pushes users to the right if current ax is less than starting ax
%starting ax is a constant point based on original orientation
if(imu_raw.ax > imu_original.ax)
    force = -abs(force);
    if(force>minForce)
        force=force-DeltaForce;
    end
    if(force>0)
        %change force more drastically when changing direction
        force=-force;
    end
    SystemParams.Damping = 4;
    gateSpeed=gateSpeed-0.005;
end

%pushes uers to left
if(imu_raw.ax < imu_original.ax)
    force = abs(force);
    if(force<maxForce)
        force=force+DeltaForce;
    end
    if(force<0)
        %change force more drastically when changing direction
        force=abs(force);
    end
    SystemParams.Damping = 4;
    gateSpeed=gateSpeed-0.005;
end


%I obtain original speed 
%decrease speed
if(imu_raw.az > imu_original.az)
    newSpeed = gateSpeed - abs(imu_raw.az - imu_original.az)*speedScale;
    if(newSpeed > 1)
     gateSpeed = newSpeed;
    end
    %slowly drop terminal speed
    if(terminalSpeed > 9.8)
        terminalSpeed = terminalSpeed-1; 
    end
end
    

%increase speed
if(imu_raw.az < imu_original.az)
    gateSpeed = gateSpeed + abs(imu_raw.az - imu_original.az)*speedScale;
    terminalSpeed = 16;
end
end

